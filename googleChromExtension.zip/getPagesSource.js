

function getMoves(){
    let movesDiv = document.getElementsByClassName("moves")[0].childNodes
    let movesLength = movesDiv.length
    let movesRes = []
    for (let i = 0 ; i < movesLength - 1 ;i++ ){
        if(i % 3 != 0){
            movesRes.push(movesDiv[i].innerHTML)
        }
    }
    console.log(movesRes)
    return movesRes
} 

chrome.runtime.sendMessage({
    action: "getSource",
    source: getMoves(document)
});

window.open("https://decodechess.com/");