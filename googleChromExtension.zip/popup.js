
function getAnaliza() {
  chrome.tabs.executeScript(null, {
    file: "getPagesSource.js"
  }, function () {
    // if (chrome.runtime.lastError) {
    //   console.log(chrome.runtime)
    // }
    // else {
    //   console.log(chrome.runtime)
    //   console.log("open new tab")
    // }
  });
}
document.addEventListener('DOMContentLoaded', function () {
  var link = document.getElementById('getAnaliza');
  link.addEventListener('click', function () {
    getAnaliza();
    // chrome.tabs.create({ url: "https://www.google.com/" });
  });
});
